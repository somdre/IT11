
function retrieveEmail() {
    return document.getElementById("username").value;
}

/*
function neste() {
    if (retrieveEmail() ==)
}

*/